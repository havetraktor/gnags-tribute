# Gnags Tribute – hjemmeside

Statisk hjemmeside til hyldestbandet Gnags Tribute. Almindelig HTML/CSS/JS, ingen build-trin, ingen framework.

## Struktur

```
index.html        Forside
om-gnags.html      Om GNAGS (originalbandet)
saetliste.html     Sætliste
bandet.html        Medlemmerne
billeder.html      Billedgalleri
anmeldelser.html   Anmeldelser
koncerter.html     Koncertkalender (eksempel-datoer, ret til jeres egne)
book.html          Booking/kontakt (eksempel-info, ret til jeres egne)
styles.css         Alt design/layout
script.js          Mobilmenu (hamburger)
assets/img/        Logo og livebilleder
```

## Læg det på GitHub

1. Opret et nyt, tomt repository på [github.com/new](https://github.com/new), fx `gnags-tribute-website`.
2. Fra denne mappe, i en terminal:

   ```
   git init
   git add .
   git commit -m "Første version af Gnags Tribute-siden"
   git branch -M main
   git remote add origin https://github.com/<dit-brugernavn>/gnags-tribute-website.git
   git push -u origin main
   ```

   (Eller upload filerne direkte via GitHub's "Add file" → "Upload files" i browseren, hvis du ikke vil bruge terminal.)

3. Gå til repoet → **Settings → Pages** → under "Build and deployment", vælg **Deploy from a branch**, branch `main`, mappe `/ (root)` → **Save**.
4. Efter et minuts tid ligger siden på `https://<dit-brugernavn>.github.io/gnags-tribute-website/`.
5. Vil I have jeres eget domæne (fx gnagstribute.dk) i stedet, sæt en `CNAME`-fil med domænet i roden af repoet, og peg domænets DNS på GitHub Pages (se GitHub's guide til "Custom domain").

## To personer, samme repo

Inviter den anden person som collaborator under **Settings → Collaborators**, så kan I begge rette filerne og pushe. Det er den letteste "to-personers adgang" til lige præcis denne løsning.

## Ting der stadig skal rettes til jeres rigtige info

- `koncerter.html` – de tre rækker er eksempel-datoer
- `book.html` – mail/telefon er en pladsholder
- Evt. billeder i `assets/img/` kan skiftes ud, bare behold samme filnavne, eller ret `src=`-stierne i de tre HTML-filer der bruger dem
